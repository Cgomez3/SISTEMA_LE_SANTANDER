create procedure sp_BuscarExportados(@ini date, @fin date)
as
select CodProgramacion, Moneda, MontoTotal, CONVERT(varchar(15),Fecha,105) as Fec, UsuCrea, FecCrea 
from Prg_DataExportada where Fecha between @ini and @fin
go

create procedure sp_LCProveedoresReten
as
select distinct Ruc, RazonSocial from DataRetencionDetalle order by RazonSocial
go

create procedure sp_ConsultarDetalleRetencion (@ruc varchar(11),@fecini date, @fecfin date)
as
if @ruc = 'TODOS'
begin
 select rd.Codigo, rd.Correlativo, rd.RazonSocial, rd.Ruc, convert(varchar(15),rd.Fecha,105) as Fec,
 rd.NroDoc, rd.Importe, rd.PorcentajeReten, rd.Retencion, rd.Sunat, rd.Neto,
 isnull((select cr.NroComprobReten from NroComprobanteRetencion as cr 
 where cr.Codigo=rd.Codigo and cr.Correlativo=rd.Correlativo),'-')
 from DataRetencionDetalle as rd where rd.Retencion!=0.00
 and rd.Fecha between @fecini and @fecfin 
order by rd.Correlativo desc
end
else
begin
select rd.Codigo, rd.Correlativo, rd.RazonSocial, rd.Ruc, convert(varchar(15),rd.Fecha,105) as Fec,
 rd.NroDoc, rd.Importe, rd.PorcentajeReten, rd.Retencion, rd.Sunat, rd.Neto,
 isnull((select cr.NroComprobReten from NroComprobanteRetencion as cr 
 where cr.Codigo=rd.Codigo and cr.Correlativo=rd.Correlativo),'-')
 from DataRetencionDetalle as rd where rd.Retencion!=0.00
 and rd.Ruc=@ruc and rd.Fecha between @fecini and @fecfin 
order by rd.Correlativo desc
end
go

create procedure sp_PasarAPendiente (@numcomprob varchar(30))
as
Update Prg_Comprobante set estado='PENDIENTE', ComprobanteSujeto='SIN RET/DET'
where NumComprobante=@numcomprob
go

create procedure sp_EliminarProgExportada (@codprog int)
as
delete from Prg_DataExportada where CodProgramacion=@codprog
Update Prg_ProgPagosCabecera set estado_progpagos='PENDIENTE' where cod_programacion=@codprog
go


create procedure sp_ListarCRetencionxExport(@mes int, @a�o int)
as
 select rd.Ruc ,rd.RazonSocial, 
 isnull((select pc.TipoComprobante from Prg_Comprobante as pc where rd.NroDoc=pc.NumComprobante),'FT') as TipoComp,
 convert(varchar(15),rd.Fecha,105) as Fec,convert(varchar(15),rd.FechaPago,105) as FechaRetencion,
 rd.NroDoc, rd.TipoMoneda, rd.Retencion, ((case rd.TipoMoneda when 'US$' then 
 cast((rd.Importe*rd.TipoCambio) as numeric(18,2)) else rd.Importe end)-rd.Retencion) as TotalNeto,
 isnull((select cr.NroComprobReten from NroComprobanteRetencion as cr 
 where cr.Codigo=rd.Codigo and cr.Correlativo=rd.Correlativo),'-') as CorrRetencion,
 (select SUM(rd2.Importe) from DataRetencionDetalle as rd2 
 where rd2.Ruc=rd.Ruc and rd.Retencion!=0.00 and rd.Correlativo=rd2.Correlativo) as ImporteBruto, rd.TipoCambio
 from DataRetencionDetalle as rd where rd.Retencion!=0.00 and MONTH(rd.Fecha)=@mes and YEAR(rd.Fecha)=@a�o
 order by rd.FechaPago
 go

 --select pc.CodComprobante, pc.DocProveedor,pc.CodMoneda, pc.CodDetraccion, pp.CuentaDetracciones, 
 --(case pc.CodMoneda when 1 then pc.MontoRetDet else pc.MontoRetDetDOL end),'01',
 --pc.TipoComprobante, pc.NumComprobante,
 --( select SUM(case pc.CodMoneda when 1 then pc.MontoRetDet else pc.MontoRetDetDOL end)  from Prg_Comprobante 
 --as pc, Prg_Proveedor as pp where pc.DocProveedor=pp.DocProveedor
 --and ComprobanteSujeto='DETRACCION' and MONTH(pc.FechaComprobante)=6 and YEAR(pc.FechaComprobante)=2015) as Sumatotal
 --  from Prg_Comprobante 
 --as pc, Prg_Proveedor as pp where pc.DocProveedor=pp.DocProveedor
 --and ComprobanteSujeto='DETRACCION' and MONTH(pc.FechaComprobante)=6 and YEAR(pc.FechaComprobante)=2015
 --order by FechaComprobante 

create procedure sp_ListarDetraccionTxt(@mes int, @a�o int)
as
 select pc.CodComprobante, pc.DocProveedor,pc.CodMoneda, pc.CodDetraccion, pp.CuentaDetracciones, 
 ROUND(pc.MontoRetDet,1),'01',
 pc.TipoComprobante, pc.NumComprobante,
 ( select SUM(ROUND(pc.MontoRetDet,1))  from Prg_Comprobante 
 as pc, Prg_Proveedor as pp where pc.DocProveedor=pp.DocProveedor
 and ComprobanteSujeto='DETRACCION' and MONTH(pc.FechaComprobante)=@mes and YEAR(pc.FechaComprobante)=@a�o) as Sumatotal
   from Prg_Comprobante 
 as pc, Prg_Proveedor as pp where pc.DocProveedor=pp.DocProveedor
 and ComprobanteSujeto='DETRACCION' and MONTH(pc.FechaComprobante)=@mes and YEAR(pc.FechaComprobante)=@a�o
 order by FechaComprobante 
go

create procedure sp_ListarParaExportarAGP
(@ini date, @fin date, @moneda varchar(10))
as
declare @codmoneda int
if @moneda = 'SOLES'
begin
set @codmoneda=1
end
else
begin
set @codmoneda=2
end
select CONVERT(varchar(15),FechaComprobante,105), DocProveedor, 
(case CodMoneda when 1 then MontoPagar else MontoPagarDOL end),
GlosaComprobante
 from Prg_Comprobante where CodMoneda=@codmoneda and estado='CANCELADO' and FechaComprobante between @ini and @fin
 go